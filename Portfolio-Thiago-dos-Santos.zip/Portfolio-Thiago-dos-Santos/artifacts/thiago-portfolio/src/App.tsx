import { type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();

function Home() {
  return (
    <div className="portfolio">
      <header className="site-header">
        <a className="wordmark" href="#inicio" aria-label="Thiago dos Santos — início">
          <span className="mark" aria-hidden="true"><span>TS</span></span>
          <span>Thiago dos Santos</span>
        </a>
        <span className="header-note">Acesso por cordas <span aria-hidden="true">/</span> Brasil</span>
      </header>

      <main>
        <section className="hero" id="inicio" aria-labelledby="hero-title">
          <div className="hero-copy">
            <p className="eyebrow reveal">Trabalho em altura</p>
            <h1 className="reveal reveal-delay" id="hero-title">Thiago <span>dos Santos</span></h1>
            <p className="role-line reveal reveal-late">Alpinista industrial N2</p>
            <div className="hero-bottom reveal reveal-late">
              <a className="contact-button" href="https://wa.me/5531971052977" target="_blank" rel="noreferrer" aria-label="Falar com Thiago pelo WhatsApp" data-testid="link-contato-hero">
                <span>Entrar em contato</span>
                <svg width="15" height="15" viewBox="0 0 16 16" fill="none" aria-hidden="true">
                  <path d="M3.25 12.75 12.5 3.5M5 3.5h7.5V11" stroke="currentColor" strokeWidth="1.3" />
                </svg>
              </a>
              <span className="hero-aside">Cuidado no preparo.<br />Precisão em cada etapa.</span>
            </div>
          </div>
          <div className="hero-visual" aria-label="Ilustração técnica de acesso por cordas junto a uma estrutura vertical" role="img">
            <svg className="height-art" viewBox="0 0 480 460" fill="none" aria-hidden="true">
              <circle className="art-ring art-pulse" cx="250" cy="224" r="177" />
              <circle className="art-ring" cx="250" cy="224" r="143" />
              <path className="art-line art-dash" d="M30 365H440M70 92H410" />
              <path className="art-building" d="M294 65h99v300h-99z" />
              <path className="art-building" d="M277 65h17v300h-17z" />
              <path className="art-window" d="M310 86h68v55h-68zm0 74h68v55h-68zm0 74h68v55h-68zm0 74h68v38h-68z" />
              <path className="art-line" d="M277 65h117M271 365h128M326 54v-15m-26 0h53" />
              <path className="art-rig" d="M326 39v114c0 15-11 27-25 27h-5m5 0c15 0 25 12 25 27v95" />
              <path className="art-line" d="M326 126h-34M326 280h-34M284 179l-10 8 10 8" />
              <circle cx="326" cy="177" r="4" fill="#a9cce0" />
              <path className="art-worker" d="M286 173a8 8 0 1 0 0 16 8 8 0 0 0 0-16Zm-4 17 9 2 8 13-5 3-7-9-5 12 7 12-5 3-10-14 2-11-8 9-5-3 11-15 8-2Z" />
              <path className="art-line" d="m290 205 9 19m-20-1 7-9m4 4 8 7" />
              <circle cx="286" cy="181" r="17" className="art-ring" />
              <path className="art-line" d="M116 273h92m-92 10h57m-57 10h72" />
              <text className="art-label" x="116" y="255">TRABALHO EM ALTURA</text>
              <text className="art-label" x="296" y="399">ACESSO POR CORDAS</text>
              <path className="art-line" d="M107 247v72m0-72h9m-9 72h9" />
            </svg>
            <span className="visual-caption">Preparação · Acesso · Trabalho</span>
          </div>
          <div className="scroll-cue" aria-hidden="true">Conheça o profissional</div>
        </section>

        <div className="section-wrap"><div className="section-rule" /></div>

        <section className="about-section section-wrap" id="sobre" aria-labelledby="about-title">
          <div>
            <p className="section-number">01 / Sobre</p>
          </div>
          <div className="about-content">
            <h2 className="section-title" id="about-title">Sobre mim</h2>
            <p style={{ marginTop: 28 }} data-testid="text-about">
              Sou Thiago dos Santos, alpinista industrial N2, com 7 anos de atuação na área de acesso por cordas. No trabalho em altura,
              valorizo o <em>planejamento, a atenção aos procedimentos e o cuidado em cada etapa</em>.
            </p>
          </div>
        </section>

        <div className="section-wrap"><div className="section-rule" /></div>

        <section className="skills-section section-wrap" id="atuacao" aria-labelledby="skills-title">
          <div>
            <p className="section-number">02 / Atuação</p>
            <h2 className="section-title" id="skills-title">Serviços</h2>
            <p className="skills-intro">Serviços industriais e de acesso por cordas.</p>
          </div>
          <ul className="skills-list" aria-label="Serviços realizados por Thiago">
            <li className="skill-row" data-testid="service-welding">
              <span className="skill-index">01</span><span className="skill-name">Solda</span><span className="skill-mark" aria-hidden="true" />
            </li>
            <li className="skill-row" data-testid="service-industrial-painting">
              <span className="skill-index">02</span><span className="skill-name">Pintura industrial</span><span className="skill-mark" aria-hidden="true" />
            </li>
            <li className="skill-row" data-testid="service-industrial-rescue">
              <span className="skill-index">03</span><span className="skill-name">Resgate industrial</span><span className="skill-mark" aria-hidden="true" />
            </li>
            <li className="skill-row" data-testid="service-anchor-points">
              <span className="skill-index">04</span><span className="skill-name">Instalação de pontos de ancoragem</span><span className="skill-mark" aria-hidden="true" />
            </li>
            <li className="skill-row" data-testid="service-lifeline">
              <span className="skill-index">05</span><span className="skill-name">Instalação de linha de vida</span><span className="skill-mark" aria-hidden="true" />
            </li>
            <li className="skill-row" data-testid="service-general-maintenance">
              <span className="skill-index">06</span><span className="skill-name">Manutenção em geral</span><span className="skill-mark" aria-hidden="true" />
            </li>
          </ul>
        </section>

        <section className="contact-section" id="contato" aria-labelledby="contact-title">
          <div className="contact-inner">
            <div>
              <p className="eyebrow">03 / Contato</p>
              <h2 id="contact-title">Vamos conversar<br />sobre o seu projeto?</h2>
              <a className="contact-number" href="tel:+5531971052977">+55 (31) 97105-2977</a>
            </div>
            <a className="contact-button" href="https://wa.me/5531971052977" target="_blank" rel="noreferrer" data-testid="link-contato-footer" aria-label="Falar com Thiago pelo WhatsApp">
              <span>Entrar em contato</span>
              <svg width="15" height="15" viewBox="0 0 16 16" fill="none" aria-hidden="true">
                <path d="M3.25 12.75 12.5 3.5M5 3.5h7.5V11" stroke="currentColor" strokeWidth="1.3" />
              </svg>
            </a>
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <span className="footer-name">Thiago dos Santos</span>
        <span>Alpinista industrial N2</span>
        <span>Brasil</span>
      </footer>
    </div>
  );
}

function Router() {
  return (
    // Keep a shared shell (sidebar, navbar) outside the boundary so it
    // survives a page crash.
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
